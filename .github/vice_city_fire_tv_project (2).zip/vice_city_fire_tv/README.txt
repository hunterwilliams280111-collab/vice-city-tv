VICE CITY TV — FIRE TV APP PROJECT

This is an unofficial, lightweight Vice City-inspired home-screen app for Fire TV / Android TV.
It includes a remote-friendly dashboard, app shortcuts, decorative promo panels and neon styling.
It does NOT replace Amazon's protected system launcher.

DEVICE COMPATIBILITY
- Minimum Android API 21 (Android 5.0); designed for a broad range of Fire OS devices.
- No device-specific CPU libraries are included, so the APK is not tied to one Fire TV model.
- No APK can be guaranteed on every Fire TV: very old devices, changed app package names, or Amazon OS restrictions can affect compatibility.
- Some app shortcuts only work if that app is installed and uses the listed package name.

GET A DOWNLOADABLE APK (NO ANDROID STUDIO REQUIRED)
You need a GitHub account and a computer once to publish the project. After that, download the APK directly on the Fire TV.

1. On a computer, sign in to https://github.com and create a NEW PUBLIC repository. Call it vice-city-tv.
2. Extract this ZIP. In the new repository, choose Add file > Upload files.
3. Upload the CONTENTS of the extracted folder (including the hidden .github folder and its workflow file), then commit the upload to the main branch.
4. Open the repository's Actions tab. Choose "Build Vice City Fire TV APK" and press "Run workflow". Wait for the run to finish successfully.
5. Open the repository's Releases page. The release named "Vice City TV v1.0" will contain app-debug.apk.
6. On the Fire TV, open the Silk browser and visit:
   https://github.com/YOUR-GITHUB-NAME/vice-city-tv/releases/latest
   Replace YOUR-GITHUB-NAME with your GitHub username. Select app-debug.apk to download it.
7. Open the downloaded APK and follow the Fire TV install prompt. If Fire TV blocks it, enable permission for Silk to install unknown apps in Settings > My Fire TV > Developer Options > Install unknown apps. Menu names vary by Fire OS version. Turn that permission off again after installation if you prefer.

If Developer Options is missing, on many Fire TV models go to Settings > My Fire TV > About, highlight the device name, and press the select button seven times. This reveals Developer Options on supported versions.

PROJECT BUILD DETAILS
- Android application ID: com.example.vicecitytv
- Minimum SDK: 21
- Target SDK: 28 (chosen for compatibility with older Fire OS releases)
- Build command: gradle assembleDebug
- Output: app/build/outputs/apk/debug/app-debug.apk
- GitHub Actions workflow builds the APK and publishes it as a GitHub release asset automatically.

NOTES
- The promo cards are sample decorative banners, not paid adverts or live advertising.
- This is a fan-made theme, not an official GTA VI product. It does not include Rockstar artwork, game files, or logos.
- The app is a standalone dashboard; Amazon may not allow third-party apps to replace its default home screen.
