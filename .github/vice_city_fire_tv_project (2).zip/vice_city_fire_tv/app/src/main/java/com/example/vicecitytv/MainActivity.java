package com.example.vicecitytv;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.view.KeyEvent;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private WebView web;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.setBackgroundColor(0xFF090A18);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new TVBridge(), "TV");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (web != null && event.getAction() == KeyEvent.ACTION_DOWN) {
            int key = event.getKeyCode();
            if (key == KeyEvent.KEYCODE_DPAD_UP || key == KeyEvent.KEYCODE_DPAD_DOWN ||
                key == KeyEvent.KEYCODE_DPAD_LEFT || key == KeyEvent.KEYCODE_DPAD_RIGHT ||
                key == KeyEvent.KEYCODE_DPAD_CENTER || key == KeyEvent.KEYCODE_ENTER ||
                key == KeyEvent.KEYCODE_BACK) {
                web.evaluateJavascript("window.handleRemoteKey && window.handleRemoteKey(" + key + ")", null);
                if (key != KeyEvent.KEYCODE_BACK) return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    public class TVBridge {
        @JavascriptInterface public void launch(String packageName) {
            runOnUiThread(() -> {
                try {
                    Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
                    if (launch != null) startActivity(launch);
                    else Toast.makeText(MainActivity.this, "That app is not installed.", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not open that app.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface public String installedApps() {
            PackageManager pm = getPackageManager();
            Intent intent = new Intent(Intent.ACTION_MAIN, null);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> found = pm.queryIntentActivities(intent, 0);
            ArrayList<String> names = new ArrayList<>();
            for (ResolveInfo info : found) {
                String label = info.loadLabel(pm).toString();
                String pkg = info.activityInfo.packageName;
                if (!pkg.equals(getPackageName())) names.add(label.replace("|"," ") + "|" + pkg);
            }
            return android.text.TextUtils.join("\n", names);
        }
    }

    @Override protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
